function validateForm() {
    const form = document.getElementById('myForm');
    const errorMessages = document.getElementById('errorMessages');
    errorMessages.innerHTML = ''; 
    const firstName = form.elements['firstName'].value.trim();
    const lastName = form.elements['lastName'].value.trim();
    const email = form.elements['email'].value.trim();
    const age = form.elements['age'].value.trim();
    const dob = form.elements['dob'].value.trim();

    const nameRegex = /^[a-zA-Z]+$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const ageRegex = /^\d+$/;
    const dobRegex = /^\d{4}-\d{2}-\d{2}$/;

    if (!nameRegex.test(firstName)) {
        errorMessages.innerHTML += 'Nome non valido.<br>';
    }

    if (!nameRegex.test(lastName)) {
        errorMessages.innerHTML += 'Cognome non valido.<br>';
    }

    if (!emailRegex.test(email)) {
        errorMessages.innerHTML += 'Email non valida.<br>';
    }

    if (!ageRegex.test(age) || parseInt(age) <= 0) {
        errorMessages.innerHTML += 'Età non valida.<br>';
    }

    if (!dobRegex.test(dob)) {
        errorMessages.innerHTML += 'Formato data di nascita non valido (YYYY-MM-DD).<br>';
    }

    if (errorMessages.innerHTML !== '') {
        return;
    }
    alert('Form submitted successfully!');
}
